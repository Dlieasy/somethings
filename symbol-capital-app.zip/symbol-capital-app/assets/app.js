// 个体符号资本与社会宏观调节的双层嵌套模型 — 交互式前端
// assets/app.js

(function() {
  'use strict';

  // ============================================================
  // 常量与配置
  // ============================================================
  var fieldWeights = {
    academic:       { W: 0.10, S: 0.25, C: 0.30, N: 0.20, M: 0.15 },
    business:       { W: 0.30, S: 0.20, C: 0.15, N: 0.25, M: 0.10 },
    political_auth: { W: 0.15, S: 0.35, C: 0.10, N: 0.25, M: 0.15 },
    political_demo: { W: 0.20, S: 0.25, C: 0.15, N: 0.25, M: 0.15 },
    art:            { W: 0.15, S: 0.15, C: 0.25, N: 0.20, M: 0.25 }
  };

  var fieldLabels = {
    academic: '学术场域', business: '商业场域',
    political_auth: '政治威权场域', political_demo: '政治民主场域', art: '艺术场域'
  };

  var betaValues = [0.00, 0.10, 0.50, 1.00, 0.98, 0.80, 0.45, 0.20];
  var ageLabels = ['0-12岁','13-17岁','18-25岁','26-40岁','41-55岁','56-70岁','71-80岁','81岁+'];

  var dimKeys = ['W', 'S', 'C', 'N', 'M'];
  var dimNames = ['财富 W', '社会地位 S', '能力 C', '人脉 N', '道德声望 M'];
  var dimShortNames = ['财富', '地位', '能力', '人脉', '道德'];
  var dimColors = ['#1e3a5f', '#2c5282', '#4a7c9b', '#c9a227', '#8b6914'];

  // 每个维度的子指标题名（用于结果展示）
  var dimSubLabels = {
    W: ['收入与资产水平', '应急经济缓冲能力', '可自由支配消费能力'],
    S: ['制度性职位层级', '正式头衔与称谓', '荣誉与公共认可'],
    C: ['认知与基础技能', '专业技能与资格认证', '创新与原创性贡献'],
    N: ['网络规模（联系人数量）', '网络异质性（跨职业/阶层）', '资源获取能力'],
    M: ['诚信与履约记录', '社区/共同体评价', '道德示范性行为']
  };

  var THRESHOLD = 7.0;
  var charts = {};

  // 当前步骤（0-5）
  var currentStep = 0;

  function getColors() {
    var style = getComputedStyle(document.documentElement);
    return {
      accent: style.getPropertyValue('--accent').trim() || '#1e3a5f',
      accent2: style.getPropertyValue('--accent2').trim() || '#c9a227',
      ink: style.getPropertyValue('--ink').trim() || '#1a1a2e',
      muted: style.getPropertyValue('--muted').trim() || '#6b7280',
      rule: style.getPropertyValue('--rule').trim() || '#e5e7eb',
      bg2: style.getPropertyValue('--bg2').trim() || '#ffffff',
      success: style.getPropertyValue('--success').trim() || '#059669',
      danger: style.getPropertyValue('--danger').trim() || '#dc2626',
      warning: style.getPropertyValue('--warning').trim() || '#d97706'
    };
  }

  // ============================================================
  // 导航切换
  // ============================================================
  function initNavigation() {
    var navItems = document.querySelectorAll('.nav-item');
    var sections = document.querySelectorAll('.section');
    navItems.forEach(function(item) {
      item.addEventListener('click', function() {
        var targetId = this.getAttribute('data-target');
        if (!targetId) return;
        navItems.forEach(function(n) { n.classList.remove('active'); });
        this.classList.add('active');
        sections.forEach(function(sec) {
          sec.classList.toggle('active', sec.id === targetId);
        });
        document.querySelector('.sidebar').classList.remove('open');
        setTimeout(function() {
          Object.values(charts).forEach(function(chart) {
            if (chart && typeof chart.resize === 'function') chart.resize();
          });
        }, 150);
      });
    });
  }

  // ============================================================
  // Tab 切换
  // ============================================================
  function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
      btn.classList.remove('active');
      if (btn.getAttribute('onclick') && btn.getAttribute('onclick').indexOf(tabId) > -1) {
        btn.classList.add('active');
      }
    });
    document.querySelectorAll('.tab-panel').forEach(function(panel) {
      panel.classList.toggle('active', panel.id === tabId);
    });
  }

  // ============================================================
  // 问卷步骤切换
  // ============================================================
  function goToStep(step) {
    // 隐藏所有步骤面板和结果
    for (var i = 0; i <= 5; i++) {
      var el = document.getElementById('calcStep' + i);
      if (el) el.style.display = 'none';
    }
    document.getElementById('calcResults').style.display = 'none';
    document.getElementById('calcCharts').style.display = 'none';

    // 显示目标步骤
    var target = document.getElementById('calcStep' + step);
    if (target) target.style.display = 'block';
    currentStep = step;

    // 滚动到顶部
    target && target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ============================================================
  // 问卷评分 → 维度得分映射
  // ============================================================

  // 获取某个radio组的选中值
  function getRadioValue(name) {
    var el = document.querySelector('input[name="' + name + '"]:checked');
    return el ? parseFloat(el.value) : null;
  }

  // 将3个子指标取平均值映射为维度得分（1-10）
  function computeDimScore(itemNames) {
    var vals = [];
    itemNames.forEach(function(name) {
      var v = getRadioValue(name);
      if (v !== null) vals.push(v);
    });
    if (vals.length === 0) return null;
    // 取平均值并四舍五入到一位小数
    var sum = 0;
    vals.forEach(function(v) { sum += v; });
    return Math.round((sum / vals.length) * 10) / 10;
  }

  // ============================================================
  // 百分位估算
  // ============================================================
  function estimatePercentile(totalScore) {
    if (totalScore >= 9.5) return 'Top 0.1%';
    if (totalScore >= 9.0) return 'Top 1%';
    if (totalScore >= 8.5) return 'Top 5%';
    if (totalScore >= 8.0) return 'Top 10%';
    if (totalScore >= 7.5) return 'Top 20%';
    if (totalScore >= 7.0) return 'Top 35%';
    if (totalScore >= 6.0) return 'Top 55%';
    if (totalScore >= 5.0) return 'Top 75%';
    if (totalScore >= 4.0) return 'Top 90%';
    return 'Bottom 10%';
  }

  // ============================================================
  // 完成评估 → 计算并展示结果
  // ============================================================
  function calculateAndShow() {
    // 计算各维度得分
    var scores = {
      W: computeDimScore(['w1', 'w2', 'w3']),
      S: computeDimScore(['s1', 's2', 's3']),
      C: computeDimScore(['c1', 'c2', 'c3']),
      N: computeDimScore(['n1', 'n2', 'n3']),
      M: computeDimScore(['m1', 'm2', 'm3'])
    };

    // 检查是否所有维度都有答案
    var missing = [];
    dimKeys.forEach(function(k) {
      if (scores[k] === null) {
        var label = dimShortNames[dimKeys.indexOf(k)];
        missing.push(label);
      }
    });

    if (missing.length > 0) {
      alert('请完成以下维度的所有题目后再提交：' + missing.join('、'));
      return;
    }

    var field = document.getElementById('fieldSelect').value;
    var weights = fieldWeights[field];
    var ageIdx = parseInt(document.getElementById('ageStage').value) || 3;
    var beta = betaValues[ageIdx] !== undefined ? betaValues[ageIdx] : 1.0;

    // 计算加权得分
    var weightedSum = 0;
    var contributions = {};
    dimKeys.forEach(function(k) {
      var contrib = weights[k] * scores[k];
      contributions[k] = contrib;
      weightedSum += contrib;
    });

    var total = beta * weightedSum;

    // 生成维度得分明细
    var summaryHtml = '';
    dimKeys.forEach(function(k, idx) {
      var subVals = [];
      var subNames = dimSubLabels[k];
      var prefix = k.toLowerCase();
      for (var i = 1; i <= 3; i++) {
        subVals.push(getRadioValue(prefix + i));
      }
      summaryHtml += '<div class="dim-score-row">';
      summaryHtml += '<span style="min-width:60px;font-weight:600;">' + dimShortNames[idx] + '</span>';
      summaryHtml += '<div class="dim-score-bar"><div class="inner" style="width:' + (scores[k] / 10 * 100) + '%;background:' + dimColors[idx] + ';"></div></div>';
      summaryHtml += '<span class="dim-score-val">' + scores[k].toFixed(1) + '</span>';
      summaryHtml += '</div>';
      // 子指标明细
      subNames.forEach(function(sn, si) {
        summaryHtml += '<div style="padding:.15rem 0 .15rem 70px;font-size:.78rem;color:var(--muted);">';
        summaryHtml += sn + '：<span style="color:var(--ink);font-weight:500;">' + subVals[si] + '</span></div>';
      });
    });

    document.getElementById('dimScoreSummary').innerHTML = summaryHtml;

    // 更新结果数字
    document.getElementById('resTotal').textContent = total.toFixed(2);
    document.getElementById('resBeta').textContent = beta.toFixed(2);
    document.getElementById('resWeighted').textContent = weightedSum.toFixed(2);
    document.getElementById('resPercentile').textContent = estimatePercentile(total);

    // 阈值比较
    var thresholdPct = Math.min(100, Math.max(0, (total / THRESHOLD) * 100));
    var fillEl = document.getElementById('thresholdFill');
    fillEl.style.width = thresholdPct + '%';

    if (total >= THRESHOLD) {
      fillEl.style.background = 'var(--success)';
      document.getElementById('thresholdMsg').textContent = '已跨越晋升阈值 — 进入符号资本优势区';
      document.getElementById('thresholdMsg').style.color = 'var(--success)';
    } else if (total >= THRESHOLD * 0.8) {
      fillEl.style.background = 'var(--warning)';
      document.getElementById('thresholdMsg').textContent = '接近晋升阈值 — 处于社会中上层';
      document.getElementById('thresholdMsg').style.color = 'var(--warning)';
    } else {
      fillEl.style.background = 'var(--danger)';
      document.getElementById('thresholdMsg').textContent = '未跨越晋升阈值 — 处于社会中层或以下';
      document.getElementById('thresholdMsg').style.color = 'var(--danger)';
    }

    // 隐藏步骤面板，显示结果和图表
    for (var i = 0; i <= 5; i++) {
      var el = document.getElementById('calcStep' + i);
      if (el) el.style.display = 'none';
    }
    document.getElementById('calcResults').style.display = 'block';
    document.getElementById('calcCharts').style.display = 'block';

    // 更新图表（延迟以确保DOM可见）
    setTimeout(function() {
      updateRadarChart(scores);
      updateBarChart(contributions);
      if (charts.radar) charts.radar.resize();
      if (charts.bar) charts.bar.resize();
    }, 200);

    // 滚动到结果
    document.getElementById('calcResults').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ============================================================
  // ECharts 图表
  // ============================================================

  function initRadarChart() {
    var el = document.getElementById('radarChart');
    if (!el) return;
    charts.radar = echarts.init(el, null, { renderer: 'svg' });
    window.addEventListener('resize', function() { charts.radar && charts.radar.resize(); });
  }

  function updateRadarChart(scores) {
    if (!charts.radar) return;
    var c = getColors();
    var field = document.getElementById('fieldSelect').value;
    var weights = fieldWeights[field];

    var dataRaw = dimKeys.map(function(k) { return scores[k]; });
    var dataWeighted = dimKeys.map(function(k) { return +(weights[k] * scores[k] * 3.33).toFixed(2); });

    charts.radar.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true },
      legend: { data: ['原始得分 (1-10)', '加权贡献 (放大)'], bottom: 0 },
      radar: {
        indicator: dimNames.map(function(name) { return { name: name, max: 10 }; }),
        shape: 'polygon', splitNumber: 5,
        axisName: { color: c.muted, fontSize: 12 },
        splitLine: { lineStyle: { color: c.rule } },
        splitArea: { areaStyle: { color: ['#fafafa', '#fff'] } }
      },
      series: [{
        type: 'radar',
        data: [
          {
            value: dataRaw, name: '原始得分 (1-10)',
            areaStyle: { color: 'rgba(30,58,95,0.15)' },
            lineStyle: { color: c.accent, width: 2 },
            itemStyle: { color: c.accent }
          },
          {
            value: dataWeighted, name: '加权贡献 (放大)',
            areaStyle: { color: 'rgba(201,162,39,0.12)' },
            lineStyle: { color: c.accent2, width: 2, type: 'dashed' },
            itemStyle: { color: c.accent2 }
          }
        ]
      }]
    }, true);
  }

  function initBarChart() {
    var el = document.getElementById('barChart');
    if (!el) return;
    charts.bar = echarts.init(el, null, { renderer: 'svg' });
    window.addEventListener('resize', function() { charts.bar && charts.bar.resize(); });
  }

  function updateBarChart(contributions) {
    if (!charts.bar) return;
    var c = getColors();

    charts.bar.setOption({
      animation: false,
      tooltip: { trigger: 'axis', appendToBody: true, formatter: '{b}: {c}' },
      grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
      xAxis: {
        type: 'category', data: dimShortNames,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted }
      },
      yAxis: {
        type: 'value', name: '加权贡献 w×D', max: 5,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted },
        splitLine: { lineStyle: { color: '#f0f0f0' } }
      },
      series: [{
        type: 'bar',
        data: dimKeys.map(function(k) { return +(contributions[k] || 0).toFixed(2); }),
        itemStyle: {
          color: function(params) { return dimColors[params.dataIndex]; },
          borderRadius: [4, 4, 0, 0]
        },
        label: { show: true, position: 'top', formatter: '{c}', color: c.muted, fontSize: 11 }
      }]
    }, true);
  }

  // ---- 桑基图 ----
  function initSankeyChart() {
    var el = document.getElementById('sankeyChart');
    if (!el) return;
    charts.sankey = echarts.init(el, null, { renderer: 'svg' });
    var c = getColors();

    var nodes = [
      { name: '制度约束 λ_legal', itemStyle: { color: c.accent } },
      { name: '再分配缓冲 τ', itemStyle: { color: '#2c5282' } },
      { name: '流动渠道 ϕ_edu', itemStyle: { color: '#4a7c9b' } },
      { name: '文化合法性 η', itemStyle: { color: c.accent2 } },
      { name: '财富 W', itemStyle: { color: c.accent } },
      { name: '社会地位 S', itemStyle: { color: '#2c5282' } },
      { name: '能力 C', itemStyle: { color: '#4a7c9b' } },
      { name: '人脉 N', itemStyle: { color: c.accent2 } },
      { name: '道德声望 M', itemStyle: { color: '#8b6914' } },
      { name: '年龄调节 β(A)', itemStyle: { color: '#6b7280' } },
      { name: '总符号资本 C_total', itemStyle: { color: c.danger } }
    ];
    var links = [
      { source: '制度约束 λ_legal', target: '财富 W', value: 3 },
      { source: '制度约束 λ_legal', target: '社会地位 S', value: 3 },
      { source: '再分配缓冲 τ', target: '财富 W', value: 2 },
      { source: '再分配缓冲 τ', target: '道德声望 M', value: 2 },
      { source: '流动渠道 ϕ_edu', target: '能力 C', value: 4 },
      { source: '流动渠道 ϕ_edu', target: '社会地位 S', value: 2 },
      { source: '文化合法性 η', target: '道德声望 M', value: 2 },
      { source: '文化合法性 η', target: '社会地位 S', value: 2 },
      { source: '财富 W', target: '总符号资本 C_total', value: 3 },
      { source: '社会地位 S', target: '总符号资本 C_total', value: 3 },
      { source: '能力 C', target: '总符号资本 C_total', value: 3 },
      { source: '人脉 N', target: '总符号资本 C_total', value: 3 },
      { source: '道德声望 M', target: '总符号资本 C_total', value: 3 },
      { source: '年龄调节 β(A)', target: '总符号资本 C_total', value: 5 }
    ];

    charts.sankey.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true },
      series: [{
        type: 'sankey', layout: 'none',
        emphasis: { focus: 'adjacency' },
        data: nodes, links: links,
        top: '5%', bottom: '5%', left: '3%', right: '3%',
        lineStyle: { color: 'gradient', curveness: 0.5, opacity: 0.4 },
        label: { fontSize: 12, color: c.ink }
      }]
    });
    window.addEventListener('resize', function() { charts.sankey && charts.sankey.resize(); });
  }

  // ---- 正反馈循环图 ----
  function initFeedbackChart() {
    var el = document.getElementById('feedbackChart');
    if (!el) return;
    charts.feedback = echarts.init(el, null, { renderer: 'svg' });
    var c = getColors();

    var nodes = [
      { name: '高初始得分', x: 300, y: 50, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '跨越阈值', x: 500, y: 150, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '优质资源', x: 500, y: 300, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '资本积累', x: 300, y: 400, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '影响力扩大', x: 100, y: 300, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '更多资源', x: 100, y: 150, symbolSize: 55, itemStyle: { color: c.success }, label: { fontSize: 11 } },
      { name: '低初始得分', x: 700, y: 50, symbolSize: 55, itemStyle: { color: c.danger }, label: { fontSize: 11 } },
      { name: '未跨阈值', x: 700, y: 150, symbolSize: 55, itemStyle: { color: c.danger }, label: { fontSize: 11 } },
      { name: '资源流失', x: 700, y: 300, symbolSize: 55, itemStyle: { color: c.danger }, label: { fontSize: 11 } },
      { name: '资本贬值', x: 700, y: 400, symbolSize: 55, itemStyle: { color: c.danger }, label: { fontSize: 11 } }
    ];
    var links = [
      { source: '高初始得分', target: '跨越阈值', lineStyle: { color: c.success } },
      { source: '跨越阈值', target: '优质资源', lineStyle: { color: c.success } },
      { source: '优质资源', target: '资本积累', lineStyle: { color: c.success } },
      { source: '资本积累', target: '影响力扩大', lineStyle: { color: c.success } },
      { source: '影响力扩大', target: '更多资源', lineStyle: { color: c.success } },
      { source: '更多资源', target: '高初始得分', lineStyle: { color: c.success, curveness: 0.3 } },
      { source: '低初始得分', target: '未跨阈值', lineStyle: { color: c.danger } },
      { source: '未跨阈值', target: '资源流失', lineStyle: { color: c.danger } },
      { source: '资源流失', target: '资本贬值', lineStyle: { color: c.danger } }
    ];

    charts.feedback.setOption({
      animation: false,
      tooltip: { appendToBody: true },
      series: [{
        type: 'graph', layout: 'none', symbol: 'circle', roam: false,
        label: { show: true, position: 'inside', color: '#fff', fontWeight: 'bold' },
        edgeSymbol: ['none', 'arrow'], edgeSymbolSize: [0, 10],
        data: nodes, links: links,
        lineStyle: { opacity: 0.8, width: 2, curveness: 0.1 },
        emphasis: { focus: 'adjacency', lineStyle: { width: 4 } }
      }]
    });
    window.addEventListener('resize', function() { charts.feedback && charts.feedback.resize(); });
  }

  // ---- 年龄曲线 ----
  function initAgeCurveChart() {
    var el = document.getElementById('ageCurveChart');
    if (!el) return;
    charts.ageCurve = echarts.init(el, null, { renderer: 'svg' });
    var c = getColors();

    charts.ageCurve.setOption({
      animation: false,
      tooltip: { trigger: 'axis', appendToBody: true },
      grid: { left: '3%', right: '4%', bottom: '8%', top: '10%', containLabel: true },
      xAxis: {
        type: 'category', data: ageLabels,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted, fontSize: 11, rotate: 20 }
      },
      yAxis: {
        type: 'value', name: 'β(A)', max: 1.1, min: 0,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted },
        splitLine: { lineStyle: { color: '#f0f0f0' } }
      },
      series: [{
        type: 'line', data: betaValues, smooth: true,
        symbol: 'circle', symbolSize: 10,
        lineStyle: { color: c.accent, width: 3 },
        itemStyle: { color: c.accent, borderColor: '#fff', borderWidth: 2 },
        areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(30,58,95,0.2)' },
          { offset: 1, color: 'rgba(30,58,95,0.02)' }
        ] } },
        markLine: {
          silent: true,
          data: [{ xAxis: '26-40岁', label: { formatter: '黄金窗口期 β=1.00', position: 'insideEndTop', color: c.accent2 },
            lineStyle: { color: c.accent2, type: 'dashed' } }]
        },
        markPoint: { data: [{ coord: ['26-40岁', 1.0], itemStyle: { color: c.accent2 } }] }
      }]
    });
    window.addEventListener('resize', function() { charts.ageCurve && charts.ageCurve.resize(); });
  }

  // ---- 场域对比图 ----
  function initFieldCompareChart() {
    var el = document.getElementById('fieldCompareChart');
    if (!el) return;
    charts.fieldCompare = echarts.init(el, null, { renderer: 'svg' });
    var c = getColors();
    var fields = Object.keys(fieldWeights);
    var fieldNamesList = fields.map(function(f) { return fieldLabels[f]; });

    var series = dimKeys.map(function(k, idx) {
      return {
        name: dimShortNames[idx], type: 'bar', stack: 'total',
        emphasis: { focus: 'series' },
        data: fields.map(function(f) { return fieldWeights[f][k]; }),
        itemStyle: { color: dimColors[idx] }
      };
    });

    charts.fieldCompare.setOption({
      animation: false,
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true },
      legend: { data: dimShortNames, bottom: 0 },
      grid: { left: '3%', right: '4%', bottom: '12%', top: '5%', containLabel: true },
      xAxis: {
        type: 'category', data: fieldNamesList,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted, fontSize: 11, rotate: 15 }
      },
      yAxis: {
        type: 'value', name: '权重', max: 1,
        axisLine: { lineStyle: { color: c.rule } },
        axisLabel: { color: c.muted },
        splitLine: { lineStyle: { color: '#f0f0f0' } }
      },
      series: series
    });
    window.addEventListener('resize', function() { charts.fieldCompare && charts.fieldCompare.resize(); });
  }

  // ---- 历史热力图 ----
  function initHistoryHeatmap() {
    var el = document.getElementById('historyHeatmap');
    if (!el) return;
    charts.historyHeatmap = echarts.init(el, null, { renderer: 'svg' });
    var c = getColors();

    var cases = ['罗马帝国晚期', '科举中国', '当代北欧', '美式模式'];
    var params = ['制度约束 λ', '再分配 τ', '流动渠道 ϕ', '文化合法性 η', '基尼系数'];
    var data = [
      [0,0,0.2],[1,0,0.0],[2,0,0.1],[3,0,0.3],[4,0,0.85],
      [0,1,0.4],[1,1,0.2],[2,1,0.9],[3,1,0.7],[4,1,0.55],
      [0,2,0.95],[1,2,0.9],[2,2,0.9],[3,2,0.85],[4,2,0.28],
      [0,3,0.6],[1,3,0.2],[2,3,0.5],[3,3,0.7],[4,3,0.42]
    ];

    charts.historyHeatmap.setOption({
      animation: false,
      tooltip: { position: 'top', appendToBody: true, formatter: function(p) {
        return cases[p.data[1]] + '<br>' + params[p.data[0]] + ': ' + p.data[2];
      } },
      grid: { left: '15%', right: '8%', top: '5%', bottom: '5%' },
      xAxis: { type: 'category', data: params, splitArea: { show: true }, axisLabel: { color: c.muted, fontSize: 11 } },
      yAxis: { type: 'category', data: cases, splitArea: { show: true }, axisLabel: { color: c.ink, fontSize: 12, fontWeight: 500 } },
      visualMap: {
        min: 0, max: 1, calculable: true, orient: 'horizontal',
        left: 'center', bottom: '0%',
        inRange: { color: ['#e8f0fe', '#1e3a5f'] },
        textStyle: { color: c.muted }
      },
      series: [{
        type: 'heatmap', data: data,
        label: { show: true, formatter: function(p) { return p.data[2]; }, color: c.ink, fontSize: 12 },
        emphasis: { itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0,0,0,0.2)' } }
      }]
    });
    window.addEventListener('resize', function() { charts.historyHeatmap && charts.historyHeatmap.resize(); });
  }

  // ============================================================
  // 初始化
  // ============================================================
  function init() {
    initNavigation();
    initRadarChart();
    initBarChart();
    initSankeyChart();
    initFeedbackChart();
    initAgeCurveChart();
    initFieldCompareChart();
    initHistoryHeatmap();
  }

  // 暴露全局函数
  window.goToStep = goToStep;
  window.calculateAndShow = calculateAndShow;
  window.switchTab = switchTab;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
